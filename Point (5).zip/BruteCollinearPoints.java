import edu.princeton.cs.algs4.StdOut;

public class BruteCollinearPoints {
    private int numSegments = 0;
    private LineSegment[] ls;
    private boolean flag = true;

    public BruteCollinearPoints(Point[] points) {   // finds all line segments containing 4 points
        int counter = 1;
            
    if (points == null)
        throw new IllegalArgumentException("Array cannot be null !");
     else
         for (Point p : points)
             if (p == null) 
                 throw new IllegalArgumentException("Point cannot be null !");
                 // like already sorted by y and slope to the points[points.length-1]
    
         ls = new LineSegment[ points.length / 3 ];
                 
                 for (int j = points.length - 1; j > 2; j--)
                 {
                     // Arrays.sort(points, points[j].slopeOrder()); 
                     for (int i = points.length - 2; i > 0; i--) 
                     {
                         if (points[i].equals(points[i-1])) 
                             throw new IllegalArgumentException("Both arguments to LineSegment constructor are the same point: ");
            
                         if (points[j].slopeTo(points[i]) == points[j].slopeTo(points[i-1])) 
                             counter++;
                         else 
                         {
                             if (counter >= 3)
                             {
                                 // like code here is checking if the same segment already included;
                                 
                                 LineSegment newLineSegment = new LineSegment(points[j], points[i]);
                                 
                                 
                                 for (LineSegment linls : ls)
                                     flag = newLineSegment.equals(linls) ? false : true; // is this segment there yet?
                                 
                                 if (flag)  // not there, let's add it
                                     ls[numSegments++] = newLineSegment;
                                 flag = true;
                             }
                            counter = 1;
                         }                         
                     } // for i
                 } // for j
             }
    
    // Throw an IllegalArgumentException if the argument to the constructor is null, 
    // if any point in the array is null, or 
    // if the argument to the constructor contains a repeated point.
    
    public int numberOfSegments() 
    { 
        return numSegments; 
    }       // the number of line segments
    
    public LineSegment[] segments() 
    {
        LineSegment[] lsCopy = ls;
        return lsCopy;
    }               // the line segments
    
    public static void main(String[] args) {   
        
        Point[] points = new Point[8];
                       
            points[0] = new Point(10000, 0);
            points[1] = new Point(0, 10000);
            points[2] = new Point(3000, 7000);
            points[3] = new Point(7000, 3000);
            points[4] = new Point(20000, 21000);
            points[5] = new Point(3000, 4000);
            points[6] = new Point(14000, 15000);
            points[7] = new Point(6000, 7000);
            
         /*   for (Point p : points)
                StdOut.println(p);
            StdOut.println("--- sorted ---");
          
            Arrays.sort(points); // by Y coordinate  only
            Arrays.sort(points, points[0].slopeOrder()); // by slope only
         
        for (Point p : points)
            StdOut.println(p); */ 
            
        
        BruteCollinearPoints bcp = new BruteCollinearPoints(points);
        StdOut.println(points[0].slopeOrder().compare(points[1], points[2]));
        StdOut.println("numberOfSegments: " + bcp.numberOfSegments());
        for (LineSegment linl : bcp.segments())
            StdOut.println(linl);
     }
}
