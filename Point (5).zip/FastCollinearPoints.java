import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import java.util.Arrays;

public class FastCollinearPoints {
    private static int counter = 1;
    private static int numSegments = 0;
    private static LineSegment[] ls;
    private static boolean flag = true;

    public FastCollinearPoints(Point[] points) 
    {
        if (points == null)
            throw new IllegalArgumentException("Array cannot be null !");
         else         
             for (Point p : points) 
                 if (p == null) 
                     throw new IllegalArgumentException("Point cannot be null !");
                
                  // like already sorted by y and slope to the points[points.length-1]
         
             Arrays.sort(points); // by Y coordinate  only
             Arrays.sort(points, points[0].slopeOrder()); // by slope only
           
             ls = new LineSegment[ points.length / 3 ];
                     
                     for (int j = points.length - 1; j > 2; j--)
                     {
                         Arrays.sort(points, points[0].slopeOrder()); // by slope only
                         
                         for (int i = points.length - 2; i > 0; i--) 
                         {
                             if (points[i].equals(points[i-1])) 
                                 throw new IllegalArgumentException("Both arguments to LineSegment constructor are the same point: ");
                
                             if (points[j].slopeTo(points[i]) == points[j].slopeTo(points[i-1])) 
                                 counter++;
                             else
                             {
                                 if (counter >= 3)
                                 {
                                     // like code here is checking if the same segment already included;
                                     
                                     LineSegment newLineSegment = new LineSegment(points[j], points[i]);
                                     
                                     for (LineSegment linls : ls)
                                         flag = newLineSegment.equals(linls) ? false : true; // is this segment there yet?
                                     
                                     if (flag)  // not there, let's add it
                                         ls[numSegments++] = newLineSegment;
                                     flag = true;
                                 }
                                counter = 1;
                              }
                             
                         } // for i
                     } // for j
             }

     // finds all line segments containing 4 or more points
    public int numberOfSegments() 
    {
        return numSegments;
        }       // the number of line segments
    public LineSegment[] segments() 
    {
        LineSegment[] lsCopy = ls;
        return lsCopy;
        }               // the line segments

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    } 

}
