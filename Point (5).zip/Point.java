import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import java.util.Comparator;

public class Point implements Comparable<Point> {
    private final int x;     // x-coordinate of this point
    private final int y;     // y-coordinate of this point
   
public Point(int x, int y) {
    this.x = x;
    this.y = y;       
   }                         // constructs the point (x, y)

   public void draw() {
       StdDraw.point(x, y);     
   }                      // draws this point
   public   void drawTo(Point that) {
       StdDraw.line(this.x, this.y, that.x, that.y);
   }                   // draws the line segment from this point to that point
   public String toString() { 
       return "(" + x + ", " + y + ")";
   }                          // string representation
   public int compareTo(Point that) 
   {
       if (this.y < that.y || (this.y == that.y && this.x < that.x)) return -1;
       if (this.y == that.y && this.x == that.x) return 0;
       return 1;
   }     // compare two points by y-coordinates, breaking ties by x-coordinates
   public double slopeTo(Point that) 
   { 
       if (this.y == that.y && this.x != that.x) return 0;
       if (this.x == that.x && this.y != that.y) return Double.POSITIVE_INFINITY;
       if (this.x == that.x && this.y == that.y) return Double.NEGATIVE_INFINITY;
       double res = 0.00000;
       res = ((double) that.y - (double) this.y) / ((double) that.x - (double) this.x);
       return res;
   }      // the slope between this point and that point
   
   
   public Comparator<Point> slopeOrder() {
       return (o1, o2) -> Double.compare(slopeTo(o1), slopeTo(o2));
   }   /* 
              // Treat horizontal, vertical, and degenerate line segments as in the slopeTo() method
                 if ((o1.y - y) / (o1.x - x) < (o2.y - y) / (o2.x - x)) return -1;
                 // if ((o1.y - y) / (o1.x - x) > (o2.y - y) / (o2.x - x)) return 1;
                 if ((o1.y - y) / (o1.x - x) == (o2.y - y) / (o2.x - x)) return 0;
                return 1;
             } //  
                 // */ 
    //   The slopeOrder() method should return a comparator that compares its two argument points by the slopes they make with the invoking point (x0, y0). Formally, the point (x1, y1) is less than the point (x2, y2) if and only if the slope (y1 − y0) / (x1 − x0) is less than the slope (y2 − y0) / (x2 − x0). Treat horizontal, vertical, and degenerate line segments as in the slopeTo() method.
  
public static void main(String[] args) {   
   Point[] points = new Point[8];
       
       points[1] = new Point(0, 10000);
       points[0] = new Point(10000, 0);
       points[2] = new Point(3000, 7000);
       points[3] = new Point(7000, 3000);
       points[4] = new Point(20000, 21000);
       points[5] = new Point(3000, 4000);
       points[6] = new Point(14000, 15000);
       points[7] = new Point(6000, 7000);
       StdOut.println(points[0].toString());   
       StdOut.println("comparison: " + points[0].slopeOrder().compare(points[1], points[2])); 
       // StdOut.println(points[0].slopeTo(points[4]));
       StdOut.println(points[0].slopeTo(points[1]));
       StdOut.println(points[0].slopeTo(points[2]));
       StdOut.println(points[0].slopeTo(points[3]));
       StdOut.println(points[0].slopeTo(points[4]));
       StdOut.println(points[7].slopeTo(points[4]));
       StdOut.println(points[0].slopeTo(points[5]));
       StdOut.println(points[7].slopeTo(points[6]));
    
       StdDraw.enableDoubleBuffering();
       StdDraw.setXscale(0, 32768);
       StdDraw.setYscale(0, 32768);
       for (Point p : points) 
       {
           p.draw();
       }
       StdDraw.show();
   }

}           // compare two points by slopes they make with this point

